from contacts_manager import load_contacts, save_contacts

def test_save_and_load():
    print("Testing Save and Load...")
    test_data = {"Test User": "9999999999"}
    save_contacts(test_data)
    loaded_data = load_contacts()

    if loaded_data == test_data:
        print("✅ Test Passed: Save and Load working")
    else:
        print("❌ Test Failed")

def test_empty_contacts():
    print("\nTesting Empty Contacts...")
    empty_data = {}
    save_contacts(empty_data)
    loaded_data = load_contacts()

    if loaded_data == empty_data:
        print("✅ Test Passed: Empty contacts handled")
    else:
        print("❌ Test Failed")

if __name__ == "__main__":
    print("=== Running Tests ===")
    test_save_and_load()
    test_empty_contacts()
    print("=== Tests Complete ===")