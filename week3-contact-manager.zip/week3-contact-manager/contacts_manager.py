import json

# Load contacts from JSON file
def load_contacts():
    try:
        with open('contacts_data.json', 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return {} # Return empty dict if file doesn't exist

# Save contacts to JSON file
def save_contacts(contacts):
    with open('contacts_data.json', 'w') as file:
        json.dump(contacts, file, indent=4)

# Add a new contact
def add_contact(contacts):
    name = input("Enter Name: ").strip().title()
    
    if name == "":
        print("Name cannot be empty!")
        return
    
    if name in contacts:
        print("Contact already exists!")
        return
    
    phone = input("Enter Phone Number: ").strip()
    
    # Validation: 10 digits only
    if len(phone) == 10 and phone.isdigit():
        contacts[name] = phone
        print(f"Contact '{name}' added successfully!")
    else:
        print("Invalid phone number! Must be 10 digits.")

# Search for a contact
def search_contact(contacts):
    name = input("Enter Name to Search: ").strip().title()
    
    if name in contacts:
        print(f"Name: {name}, Phone: {contacts[name]}")
    else:
        print("Contact not found!")

# Update existing contact
def update_contact(contacts):
    name = input("Enter Name to Update: ").strip().title()
    
    if name in contacts:
        new_phone = input("Enter New Phone Number: ").strip()
        
        if len(new_phone) == 10 and new_phone.isdigit():
            contacts[name] = new_phone
            print(f"Contact '{name}' updated successfully!")
        else:
            print("Invalid phone number! Must be 10 digits.")
    else:
        print("Contact not found!")

# Delete a contact
def delete_contact(contacts):
    name = input("Enter Name to Delete: ").strip().title()
    
    if name in contacts:
        del contacts[name]
        print(f"Contact '{name}' deleted successfully!")
    else:
        print("Contact not found!")

# Display all contacts
def display_all(contacts):
    if not contacts:
        print("No contacts found!")
    else:
        print("\n--- All Contacts ---")
        for name, phone in contacts.items():
            print(f"Name: {name} | Phone: {phone}")
        print("--------------------")

# Main menu function
def main():
    contacts = load_contacts()
    
    while True:
        print("\n===== Contact Management System =====")
        print("1. Add Contact")
        print("2. Search Contact")
        print("3. Update Contact")
        print("4. Delete Contact")
        print("5. Display All Contacts")
        print("6. Exit")
        
        choice = input("Enter your choice: ").strip()
        
        if choice == '1':
            add_contact(contacts)
        elif choice == '2':
            search_contact(contacts)
        elif choice == '3':
            update_contact(contacts)
        elif choice == '4':
            delete_contact(contacts)
        elif choice == '5':
            display_all(contacts)
        elif choice == '6':
            save_contacts(contacts)
            print("Thank you for using Contact Management System")
            break
        else:
            print("Invalid choice! Please enter 1-6")

if __name__ == "__main__":
    main()


