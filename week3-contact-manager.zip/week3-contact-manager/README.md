# Contact Management System

A simple Python project to manage contacts using JSON file storage.

## Features
- Add new contact
- Search contact by name
- Update existing contact
- Delete contact
- Display all contacts
- Data persistence using JSON

## How to Run
1. Make sure Python is installed
2. Run: `python contacts_manager.py`
3. Choose options 1-6 from menu

## How to Test
Run: `python test_contacts.py`